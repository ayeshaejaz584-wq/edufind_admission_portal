<?php
declare(strict_types=1);

header("Content-Type: text/plain; charset=UTF-8");
require_once __DIR__ . "/config.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);
    exit("Invalid request method.");
}

function postValue(string $key): string {
    return trim((string)($_POST[$key] ?? ""));
}

$id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);
if (!$id) {
    exit("ERROR|Invalid application id.");
}

$first_name     = postValue("first_name");
$last_name      = postValue("last_name");
$cnic           = postValue("cnic");
$dob            = postValue("dob");
$email          = postValue("email");
$phone          = postValue("phone");
$gender         = postValue("gender");
$city           = postValue("city");
$address        = postValue("address");
$qualification  = postValue("qualification");
$board          = postValue("board");
$roll_number    = postValue("roll_number");
$passing_year   = filter_var($_POST["passing_year"] ?? null, FILTER_VALIDATE_INT);
$total_marks    = filter_var($_POST["total_marks"] ?? null, FILTER_VALIDATE_INT);
$obtained_marks = filter_var($_POST["obtained_marks"] ?? null, FILTER_VALIDATE_INT);
$university     = postValue("university");
$campus         = postValue("campus");
$program        = postValue("program");
$session        = postValue("session");
$status         = postValue("status");

$required = [
    "First name" => $first_name,
    "Last name" => $last_name,
    "CNIC / B-Form" => $cnic,
    "Date of birth" => $dob,
    "Email" => $email,
    "Phone" => $phone,
    "Gender" => $gender,
    "City" => $city,
    "Address" => $address,
    "Qualification" => $qualification,
    "Board" => $board,
    "Passing year" => $passing_year,
    "Total marks" => $total_marks,
    "Obtained marks" => $obtained_marks,
    "University" => $university,
    "Campus" => $campus,
    "Program" => $program
];

foreach ($required as $label => $value) {
    if ($value === "" || $value === false || $value === null) {
        exit("ERROR|Please fill the required field: " . $label);
    }
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    exit("ERROR|Please enter a valid email address.");
}

$currentYear = (int)date("Y");
if ($passing_year < 1950 || $passing_year > $currentYear + 1) {
    exit("ERROR|Please enter a valid passing year.");
}

if ($total_marks <= 0) {
    exit("ERROR|Total marks must be greater than 0.");
}

if ($obtained_marks < 0 || $obtained_marks > $total_marks) {
    exit("ERROR|Obtained marks are invalid.");
}

$allowedStatuses = ['Pending', 'Approved', 'Rejected'];
if (!in_array($status, $allowedStatuses, true)) {
    exit("ERROR|Invalid status value.");
}

$percentage = round(($obtained_marks / $total_marks) * 100, 2);

$sql = "UPDATE applications SET
    first_name = ?, last_name = ?, cnic = ?, dob = ?, email = ?, phone = ?,
    gender = ?, city = ?, address = ?, qualification = ?, board = ?, roll_number = ?,
    passing_year = ?, total_marks = ?, obtained_marks = ?, percentage = ?,
    university = ?, campus = ?, program = ?, session = ?, status = ?
    WHERE id = ?";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    exit("ERROR|" . $conn->error);
}

$stmt->bind_param(
    "ssssssssssssiiidsssssi",
    $first_name,
    $last_name,
    $cnic,
    $dob,
    $email,
    $phone,
    $gender,
    $city,
    $address,
    $qualification,
    $board,
    $roll_number,
    $passing_year,
    $total_marks,
    $obtained_marks,
    $percentage,
    $university,
    $campus,
    $program,
    $session,
    $status,
    $id
);

if ($stmt->execute()) {
    echo "SUCCESS|Updated";
} else {
    echo "ERROR|" . $stmt->error;
}

$stmt->close();
$conn->close();
?>
