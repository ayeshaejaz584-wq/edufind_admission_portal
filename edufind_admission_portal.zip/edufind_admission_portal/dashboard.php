<?php
declare(strict_types=1);
require_once __DIR__ . "/config.php";

/* ---------- Filters ---------- */
$status   = trim((string)($_GET['status'] ?? 'All'));
$search   = trim((string)($_GET['search'] ?? ''));
$page     = max(1, (int)($_GET['page'] ?? 1));
$perPage  = 12;
$offset   = ($page - 1) * $perPage;

$where  = [];
$params = [];
$types  = "";

if ($status !== '' && $status !== 'All') {
    $where[] = "status = ?";
    $params[] = $status;
    $types   .= "s";
}

if ($search !== '') {
    $where[] = "(first_name LIKE ? OR last_name LIKE ? OR application_id LIKE ? OR cnic LIKE ? OR email LIKE ?)";
    $like = "%{$search}%";
    array_push($params, $like, $like, $like, $like, $like);
    $types .= "sssss";
}

$whereSql = $where ? ("WHERE " . implode(" AND ", $where)) : "";

/* ---------- Stats ---------- */
$stats = ['Pending' => 0, 'Approved' => 0, 'Rejected' => 0, 'Total' => 0];
$res = $conn->query("SELECT status, COUNT(*) AS c FROM applications GROUP BY status");
if ($res) {
    while ($row = $res->fetch_assoc()) {
        $stats[$row['status']] = (int)$row['c'];
        $stats['Total'] += (int)$row['c'];
    }
}

$avgPercentRow = $conn->query("SELECT ROUND(AVG(percentage),2) AS avgp FROM applications")->fetch_assoc();
$avgPercent = $avgPercentRow['avgp'] ?? 0;

$byUniversity = [];
$uRes = $conn->query("SELECT university, COUNT(*) AS c FROM applications GROUP BY university ORDER BY c DESC LIMIT 6");
if ($uRes) {
    while ($row = $uRes->fetch_assoc()) {
        $byUniversity[] = $row;
    }
}

$recentRes = $conn->query("SELECT COUNT(*) AS c FROM applications WHERE created_at >= (NOW() - INTERVAL 7 DAY)");
$recentCount = $recentRes ? (int)$recentRes->fetch_assoc()['c'] : 0;

/* ---------- Count for pagination ---------- */
$countSql = "SELECT COUNT(*) AS c FROM applications $whereSql";
$countStmt = $conn->prepare($countSql);
if ($types !== "") {
    $countStmt->bind_param($types, ...$params);
}
$countStmt->execute();
$totalRows = (int)$countStmt->get_result()->fetch_assoc()['c'];
$totalPages = max(1, (int)ceil($totalRows / $perPage));

/* ---------- Fetch rows ---------- */
$sql = "SELECT id, application_id, first_name, last_name, cnic, dob, email, phone,
               gender, city, address, qualification, board, roll_number, passing_year,
               total_marks, obtained_marks, percentage, university, campus, program,
               session, status, created_at,
               academic_document, cnic_document, photo_document
        FROM applications
        $whereSql
        ORDER BY created_at DESC
        LIMIT ? OFFSET ?";

$stmt = $conn->prepare($sql);
$allTypes = $types . "ii";
$allParams = $params;
array_push($allParams, $perPage, $offset);
$stmt->bind_param($allTypes, ...$allParams);
$stmt->execute();
$applications = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

function h(?string $v): string {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>EduFind Admission — Dashboard</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.8.2/jspdf.plugin.autotable.min.js"></script>
<style>
  :root{
    --bg:#0f172a; --panel:#1e293b; --panel2:#16213a; --border:#2c3b56;
    --text:#e6ebf5; --muted:#93a2c0; --accent:#5b8cff; --accent2:#7c5bff;
    --green:#22c55e; --yellow:#f5a623; --red:#ef4444;
    font-family:"Segoe UI",Roboto,Helvetica,Arial,sans-serif;
  }
  *{box-sizing:border-box;}
  body{margin:0;background:linear-gradient(180deg,#0b1120,#0f172a 30%);color:var(--text);}
  .wrap{max-width:1320px;margin:0 auto;padding:28px 20px 60px;}
  header.top{display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;flex-wrap:wrap;gap:12px;}
  header.top h1{font-size:22px;margin:0;font-weight:700;letter-spacing:.3px;}
  header.top h1 span{color:var(--accent);}
  header.top p{margin:4px 0 0;color:var(--muted);font-size:13px;}
  .badge-live{display:inline-flex;align-items:center;gap:6px;background:#132217;color:var(--green);border:1px solid #1f4a2b;padding:6px 12px;border-radius:20px;font-size:12px;}
  .badge-live i{width:8px;height:8px;border-radius:50%;background:var(--green);display:inline-block;box-shadow:0 0 8px var(--green);}

  .stats-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:16px;margin-bottom:22px;}
  .stat-card{background:linear-gradient(145deg,var(--panel),var(--panel2));border:1px solid var(--border);border-radius:14px;padding:18px 20px;position:relative;overflow:hidden;}
  .stat-card .label{color:var(--muted);font-size:12.5px;text-transform:uppercase;letter-spacing:.5px;}
  .stat-card .value{font-size:30px;font-weight:700;margin-top:6px;}
  .stat-card.total .value{color:var(--accent);}
  .stat-card.pending .value{color:var(--yellow);}
  .stat-card.approved .value{color:var(--green);}
  .stat-card.rejected .value{color:var(--red);}
  .stat-card .sub{color:var(--muted);font-size:11.5px;margin-top:4px;}

  .charts-row{display:grid;grid-template-columns:1.1fr 1.4fr;gap:16px;margin-bottom:24px;}
  @media(max-width:900px){.charts-row{grid-template-columns:1fr;}}
  .panel{background:var(--panel);border:1px solid var(--border);border-radius:14px;padding:18px 20px;}
  .panel h3{margin:0 0 12px;font-size:14px;color:var(--muted);text-transform:uppercase;letter-spacing:.5px;}
  .chart-box{position:relative;height:220px;}

  .toolbar{display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-bottom:16px;}
  .toolbar form{display:flex;gap:10px;flex-wrap:wrap;align-items:center;width:100%;}
  .toolbar input[type=text]{flex:1;min-width:200px;background:var(--panel2);border:1px solid var(--border);color:var(--text);padding:10px 14px;border-radius:10px;font-size:13.5px;}
  .toolbar select{background:var(--panel2);border:1px solid var(--border);color:var(--text);padding:10px 14px;border-radius:10px;font-size:13.5px;}
  .toolbar button{background:var(--accent);border:none;color:#fff;padding:10px 18px;border-radius:10px;cursor:pointer;font-size:13.5px;font-weight:600;}
  .toolbar button:hover{background:#4a7bef;}
  .toolbar .reset{background:transparent;border:1px solid var(--border);color:var(--muted);}

  table{width:100%;border-collapse:collapse;background:var(--panel);border-radius:14px;overflow:hidden;}
  thead th{text-align:left;background:var(--panel2);color:var(--muted);font-size:11.5px;text-transform:uppercase;letter-spacing:.4px;padding:12px 14px;border-bottom:1px solid var(--border);}
  tbody td{padding:13px 14px;border-bottom:1px solid var(--border);font-size:13.5px;vertical-align:middle;}
  tbody tr:hover{background:#1a2740;}
  .avatar{width:34px;height:34px;border-radius:50%;object-fit:cover;border:1px solid var(--border);background:#334;}
  .name-cell{display:flex;align-items:center;gap:10px;}
  .name-cell .meta{display:flex;flex-direction:column;}
  .name-cell .meta small{color:var(--muted);font-size:11px;}

  .pill{display:inline-block;padding:4px 11px;border-radius:20px;font-size:11.5px;font-weight:600;}
  .pill.Pending{background:#3a2f0f;color:var(--yellow);}
  .pill.Approved{background:#0f2f1c;color:var(--green);}
  .pill.Rejected{background:#3a1414;color:var(--red);}

  .actions{display:flex;gap:6px;}
  .actions button{border:none;padding:7px 11px;border-radius:8px;font-size:12px;cursor:pointer;font-weight:600;}
  .btn-view{background:#243352;color:#bcd0ff;}
  .btn-edit{background:#2e2547;color:#c9b6ff;}
  .btn-approve{background:#123a24;color:var(--green);}
  .btn-reject{background:#3a1414;color:var(--red);}
  .actions button:disabled{opacity:.35;cursor:not-allowed;}

  .pagination{display:flex;justify-content:center;gap:6px;margin-top:20px;}
  .pagination a{color:var(--muted);text-decoration:none;padding:8px 13px;border:1px solid var(--border);border-radius:8px;font-size:13px;}
  .pagination a.active{background:var(--accent);color:#fff;border-color:var(--accent);}

  .empty{text-align:center;padding:50px 20px;color:var(--muted);}

  /* Modal */
  .overlay{position:fixed;inset:0;background:rgba(5,10,20,.7);display:none;align-items:center;justify-content:center;z-index:50;padding:20px;}
  .overlay.show{display:flex;}
  .modal{background:var(--panel);border:1px solid var(--border);border-radius:16px;max-width:640px;width:100%;max-height:88vh;overflow-y:auto;padding:24px;}
  .modal h2{margin-top:0;font-size:18px;}
  .modal .grid{display:grid;grid-template-columns:1fr 1fr;gap:10px 18px;font-size:13.5px;margin:16px 0;}
  .modal .grid div span{display:block;color:var(--muted);font-size:11px;text-transform:uppercase;}
  .modal .docs{display:flex;gap:10px;flex-wrap:wrap;margin-top:12px;}
  .modal .docs a{background:var(--panel2);border:1px solid var(--border);color:var(--accent);padding:8px 12px;border-radius:8px;font-size:12.5px;text-decoration:none;}
  .modal .close{float:right;background:none;border:none;color:var(--muted);font-size:20px;cursor:pointer;}

  .form-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px 16px;margin:16px 0;}
  .form-grid.full{grid-template-columns:1fr;}
  .form-field{display:flex;flex-direction:column;gap:5px;}
  .form-field.span2{grid-column:1 / -1;}
  .form-field label{font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:.4px;}
  .form-field input, .form-field select, .form-field textarea{
    background:var(--panel2);border:1px solid var(--border);color:var(--text);
    padding:9px 12px;border-radius:8px;font-size:13.5px;font-family:inherit;
  }
  .form-field textarea{resize:vertical;min-height:60px;}
  .modal-actions{display:flex;gap:10px;justify-content:flex-end;margin-top:18px;}
  .modal-actions button{padding:10px 20px;border-radius:9px;border:none;font-size:13.5px;font-weight:600;cursor:pointer;}
  .btn-save{background:var(--accent);color:#fff;}
  .btn-cancel{background:transparent;border:1px solid var(--border) !important;color:var(--muted);}
  .form-msg{font-size:12.5px;margin-top:8px;min-height:18px;}
  .form-msg.error{color:var(--red);}
  .form-msg.success{color:var(--green);}
</style>
</head>
<body>
<div class="wrap">

  <header class="top">
    <div>
      <h1>EduFind <span>Admission Dashboard</span></h1>
      <p>Live overview of all submitted applications</p>
    </div>
    <div class="badge-live"><i></i> Connected to edufind_admission</div>
  </header>

  <div class="stats-grid">
    <div class="stat-card total">
      <div class="label">Total Applications</div>
      <div class="value"><?= (int)$stats['Total'] ?></div>
      <div class="sub"><?= $recentCount ?> new in last 7 days</div>
    </div>
    <div class="stat-card pending">
      <div class="label">Pending Review</div>
      <div class="value"><?= (int)$stats['Pending'] ?></div>
      <div class="sub">Awaiting decision</div>
    </div>
    <div class="stat-card approved">
      <div class="label">Approved</div>
      <div class="value"><?= (int)$stats['Approved'] ?></div>
      <div class="sub">Offers issued</div>
    </div>
    <div class="stat-card rejected">
      <div class="label">Rejected</div>
      <div class="value"><?= (int)$stats['Rejected'] ?></div>
      <div class="sub">Avg. score: <?= h((string)$avgPercent) ?>%</div>
    </div>
  </div>

  <div class="charts-row">
    <div class="panel">
      <h3>Status Breakdown</h3>
      <div class="chart-box"><canvas id="statusChart"></canvas></div>
    </div>
    <div class="panel">
      <h3>Top Universities by Applications</h3>
      <div class="chart-box"><canvas id="uniChart"></canvas></div>
    </div>
  </div>

  <div class="panel" style="margin-bottom:18px;">
    <div class="toolbar">
      <form method="get">
        <input type="text" name="search" placeholder="Search by name, CNIC, email or application ID..." value="<?= h($search) ?>">
        <select name="status">
          <?php foreach (['All','Pending','Approved','Rejected'] as $s): ?>
            <option value="<?= h($s) ?>" <?= $status === $s ? 'selected' : '' ?>><?= h($s) ?></option>
          <?php endforeach; ?>
        </select>
        <button type="submit">Filter</button>
        <a class="toolbar reset" href="dashboard.php" style="text-decoration:none;padding:10px 16px;border:1px solid var(--border);border-radius:10px;color:var(--muted);font-size:13.5px;">Reset</a>
        <button type="button" id="downloadPdfBtn" style="background:#22c55e;">Download PDF</button>
      </form>
    </div>

    <?php if (empty($applications)): ?>
      <div class="empty">No applications match your filters.</div>
    <?php else: ?>
    <table>
      <thead>
        <tr>
          <th>Applicant</th>
          <th>Application ID</th>
          <th>Contact</th>
          <th>University / Program</th>
          <th>Score</th>
          <th>Status</th>
          <th>Date</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($applications as $a): ?>
        <tr id="row-<?= (int)$a['id'] ?>">
          <td>
            <div class="name-cell">
              <img class="avatar" src="<?= h($a['photo_document']) ?>" onerror="this.style.visibility='hidden'">
              <div class="meta">
                <strong><?= h($a['first_name'] . ' ' . $a['last_name']) ?></strong>
                <small><?= h($a['cnic']) ?> · <?= h($a['city']) ?></small>
              </div>
            </div>
          </td>
          <td><?= h($a['application_id']) ?></td>
          <td>
            <div><?= h($a['email']) ?></div>
            <small style="color:var(--muted)"><?= h($a['phone']) ?></small>
          </td>
          <td>
            <div><?= h($a['university']) ?></div>
            <small style="color:var(--muted)"><?= h($a['program']) ?> · <?= h($a['campus']) ?></small>
          </td>
          <td><strong><?= h((string)$a['percentage']) ?>%</strong></td>
          <td><span class="pill <?= h($a['status']) ?>" id="pill-<?= (int)$a['id'] ?>"><?= h($a['status']) ?></span></td>
          <td><?= h(date('d M Y', strtotime((string)$a['created_at']))) ?></td>
          <td>
            <div class="actions">
              <button class="btn-view" onclick='openModal(<?= (int)$a['id'] ?>)'>View</button>
              <button class="btn-edit" onclick='openEditModal(<?= (int)$a['id'] ?>)'>Edit</button>
              <button class="btn-approve" onclick="updateStatus(<?= (int)$a['id'] ?>, 'Approved', this)" <?= $a['status'] === 'Approved' ? 'disabled' : '' ?>>Approve</button>
              <button class="btn-reject" onclick="updateStatus(<?= (int)$a['id'] ?>, 'Rejected', this)" <?= $a['status'] === 'Rejected' ? 'disabled' : '' ?>>Reject</button>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

    <div class="pagination">
      <?php for ($p = 1; $p <= $totalPages; $p++): ?>
        <a href="?page=<?= $p ?>&status=<?= urlencode($status) ?>&search=<?= urlencode($search) ?>" class="<?= $p === $page ? 'active' : '' ?>"><?= $p ?></a>
      <?php endfor; ?>
    </div>
    <?php endif; ?>
  </div>
</div>

<div class="overlay" id="modalOverlay">
  <div class="modal" id="modalContent">
    Loading...
  </div>
</div>

<script>
const applications = <?= json_encode($applications, JSON_HEX_TAG | JSON_HEX_APOS) ?>;

document.getElementById('downloadPdfBtn').addEventListener('click', function () {
  const btn = this;
  const originalText = btn.textContent;
  btn.textContent = 'Preparing...';
  btn.disabled = true;

  const params = new URLSearchParams({
    status: document.querySelector('select[name="status"]').value,
    search: document.querySelector('input[name="search"]').value
  });

  fetch('export_data.php?' + params.toString())
    .then(r => r.json())
    .then(data => {
      const { jsPDF } = window.jspdf;
      const doc = new jsPDF({ orientation: 'landscape' });

      doc.setFontSize(16);
      doc.text('EduFind Admission - Applications Report', 14, 15);
      doc.setFontSize(10);
      doc.text('Generated on: ' + new Date().toLocaleString(), 14, 21);
      doc.text('Total records in this report: ' + data.length, 14, 26);

      const rows = data.map(a => [
        a.application_id,
        a.first_name + ' ' + a.last_name,
        a.cnic,
        a.email,
        a.phone,
        a.university,
        a.program,
        a.percentage + '%',
        a.status,
        a.created_at ? a.created_at.split(' ')[0] : ''
      ]);

      doc.autoTable({
        startY: 32,
        head: [['App ID', 'Name', 'CNIC', 'Email', 'Phone', 'University', 'Program', 'Score', 'Status', 'Date']],
        body: rows,
        styles: { fontSize: 8, cellPadding: 2 },
        headStyles: { fillColor: [91, 140, 255] },
        theme: 'striped'
      });

      doc.save('edufind_applications_' + new Date().toISOString().slice(0,10) + '.pdf');
      btn.textContent = originalText;
      btn.disabled = false;
    })
    .catch(() => {
      alert('Could not generate PDF. Please check your connection and try again.');
      btn.textContent = originalText;
      btn.disabled = false;
    });
});

function openModal(id) {
  const a = applications.find(x => parseInt(x.id) === id);
  if (!a) return;
  const modal = document.getElementById('modalContent');
  modal.innerHTML = `
    <button class="close" onclick="closeModal()">&times;</button>
    <h2>${a.first_name} ${a.last_name}</h2>
    <div class="grid">
      <div><span>Application ID</span>${a.application_id}</div>
      <div><span>CNIC</span>${a.cnic}</div>
      <div><span>Email</span>${a.email}</div>
      <div><span>Phone</span>${a.phone}</div>
      <div><span>City</span>${a.city}</div>
      <div><span>Score</span>${a.percentage}%</div>
      <div><span>University</span>${a.university}</div>
      <div><span>Campus</span>${a.campus}</div>
      <div><span>Program</span>${a.program}</div>
      <div><span>Status</span>${a.status}</div>
    </div>
    <div class="docs">
      <a href="${a.academic_document}" target="_blank">Academic Document</a>
      <a href="${a.cnic_document}" target="_blank">CNIC Document</a>
      <a href="${a.photo_document}" target="_blank">Photo</a>
    </div>
  `;
  document.getElementById('modalOverlay').classList.add('show');
}
function closeModal() {
  document.getElementById('modalOverlay').classList.remove('show');
}

function field(label, name, value, type = 'text') {
  return `<div class="form-field">
    <label>${label}</label>
    <input type="${type}" name="${name}" value="${(value ?? '').toString().replace(/"/g,'&quot;')}">
  </div>`;
}

function openEditModal(id) {
  const a = applications.find(x => parseInt(x.id) === id);
  if (!a) return;
  const modal = document.getElementById('modalContent');
  modal.innerHTML = `
    <button class="close" onclick="closeModal()">&times;</button>
    <h2>Edit Application — ${a.application_id}</h2>
    <form id="editForm">
      <input type="hidden" name="id" value="${a.id}">
      <div class="form-grid">
        ${field('First Name','first_name',a.first_name)}
        ${field('Last Name','last_name',a.last_name)}
        ${field('CNIC / B-Form','cnic',a.cnic)}
        ${field('Date of Birth','dob',a.dob,'date')}
        ${field('Email','email',a.email,'email')}
        ${field('Phone','phone',a.phone)}
        <div class="form-field">
          <label>Gender</label>
          <select name="gender">
            ${['Male','Female','Other'].map(g => `<option value="${g}" ${a.gender===g?'selected':''}>${g}</option>`).join('')}
          </select>
        </div>
        ${field('City','city',a.city)}
        <div class="form-field span2">
          <label>Address</label>
          <textarea name="address">${a.address ?? ''}</textarea>
        </div>
        ${field('Qualification','qualification',a.qualification)}
        ${field('Board','board',a.board)}
        ${field('Roll Number','roll_number',a.roll_number)}
        ${field('Passing Year','passing_year',a.passing_year,'number')}
        ${field('Total Marks','total_marks',a.total_marks,'number')}
        ${field('Obtained Marks','obtained_marks',a.obtained_marks,'number')}
        ${field('University','university',a.university)}
        ${field('Campus','campus',a.campus)}
        ${field('Program','program',a.program)}
        ${field('Session','session',a.session)}
        <div class="form-field">
          <label>Status</label>
          <select name="status">
            ${['Pending','Approved','Rejected'].map(s => `<option value="${s}" ${a.status===s?'selected':''}>${s}</option>`).join('')}
          </select>
        </div>
      </div>
      <div class="form-msg" id="editMsg"></div>
      <div class="modal-actions">
        <button type="button" class="btn-cancel" onclick="closeModal()">Cancel</button>
        <button type="submit" class="btn-save">Save Changes</button>
      </div>
    </form>
  `;
  document.getElementById('modalOverlay').classList.add('show');
  document.getElementById('editForm').addEventListener('submit', saveEdit);
}

function saveEdit(e) {
  e.preventDefault();
  const form = e.target;
  const msg = document.getElementById('editMsg');
  const saveBtn = form.querySelector('.btn-save');
  saveBtn.disabled = true;
  msg.textContent = 'Saving...';
  msg.className = 'form-msg';

  const data = new URLSearchParams(new FormData(form));

  fetch('edit_application.php', { method: 'POST', body: data })
    .then(r => r.text())
    .then(res => {
      if (res.startsWith('SUCCESS')) {
        msg.textContent = 'Saved. Reloading...';
        msg.className = 'form-msg success';
        setTimeout(() => window.location.reload(), 700);
      } else {
        msg.textContent = res.replace('ERROR|', '');
        msg.className = 'form-msg error';
        saveBtn.disabled = false;
      }
    })
    .catch(() => {
      msg.textContent = 'Network error while saving.';
      msg.className = 'form-msg error';
      saveBtn.disabled = false;
    });
}
document.getElementById('modalOverlay').addEventListener('click', (e) => {
  if (e.target.id === 'modalOverlay') closeModal();
});

function updateStatus(id, status, btn) {
  btn.disabled = true;
  fetch('update_status.php', {
    method: 'POST',
    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
    body: `id=${id}&status=${status}`
  })
  .then(r => r.text())
  .then(res => {
    if (res.startsWith('SUCCESS')) {
      const pill = document.getElementById('pill-' + id);
      pill.textContent = status;
      pill.className = 'pill ' + status;
      const row = document.getElementById('row-' + id);
      row.querySelectorAll('.actions button').forEach(b => b.disabled = false);
      row.querySelector('.btn-' + status.toLowerCase()).disabled = true;
    } else {
      alert('Could not update status: ' + res);
      btn.disabled = false;
    }
  })
  .catch(() => {
    alert('Network error while updating status.');
    btn.disabled = false;
  });
}

/* Charts */
new Chart(document.getElementById('statusChart'), {
  type: 'doughnut',
  data: {
    labels: ['Pending', 'Approved', 'Rejected'],
    datasets: [{
      data: [<?= (int)$stats['Pending'] ?>, <?= (int)$stats['Approved'] ?>, <?= (int)$stats['Rejected'] ?>],
      backgroundColor: ['#f5a623', '#22c55e', '#ef4444'],
      borderWidth: 0
    }]
  },
  options: {
    plugins: { legend: { position: 'bottom', labels: { color: '#93a2c0' } } },
    cutout: '65%'
  }
});

new Chart(document.getElementById('uniChart'), {
  type: 'bar',
  data: {
    labels: <?= json_encode(array_column($byUniversity, 'university')) ?>,
    datasets: [{
      label: 'Applications',
      data: <?= json_encode(array_map('intval', array_column($byUniversity, 'c'))) ?>,
      backgroundColor: '#5b8cff',
      borderRadius: 6
    }]
  },
  options: {
    plugins: { legend: { display: false } },
    scales: {
      x: { ticks: { color: '#93a2c0' }, grid: { display: false } },
      y: { ticks: { color: '#93a2c0' }, grid: { color: '#2c3b56' }, beginAtZero: true }
    }
  }
});
</script>
</body>
</html>
