<?php
declare(strict_types=1);

header("Content-Type: text/plain; charset=UTF-8");
require_once __DIR__ . "/config.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);
    exit("Invalid request method.");
}

$id     = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);
$status = trim((string)($_POST['status'] ?? ''));

$allowedStatuses = ['Pending', 'Approved', 'Rejected'];

if (!$id) {
    exit("ERROR|Invalid application id.");
}

if (!in_array($status, $allowedStatuses, true)) {
    exit("ERROR|Invalid status value.");
}

$stmt = $conn->prepare("UPDATE applications SET status = ? WHERE id = ?");
if (!$stmt) {
    exit("ERROR|" . $conn->error);
}

$stmt->bind_param("si", $status, $id);

if ($stmt->execute()) {
    if ($stmt->affected_rows === 0) {
        // Either already this status, or id not found — check existence.
        $check = $conn->prepare("SELECT id FROM applications WHERE id = ?");
        $check->bind_param("i", $id);
        $check->execute();
        if ($check->get_result()->num_rows === 0) {
            exit("ERROR|Application not found.");
        }
    }
    echo "SUCCESS|" . $status;
} else {
    echo "ERROR|" . $stmt->error;
}

$stmt->close();
$conn->close();
?>
