<?php
declare(strict_types=1);
header("Content-Type: application/json; charset=UTF-8");
require_once __DIR__ . "/config.php";

$status = trim((string)($_GET['status'] ?? 'All'));
$search = trim((string)($_GET['search'] ?? ''));

$where  = [];
$params = [];
$types  = "";

if ($status !== '' && $status !== 'All') {
    $where[] = "status = ?";
    $params[] = $status;
    $types   .= "s";
}

if ($search !== '') {
    $where[] = "(first_name LIKE ? OR last_name LIKE ? OR application_id LIKE ? OR cnic LIKE ? OR email LIKE ?)";
    $like = "%{$search}%";
    array_push($params, $like, $like, $like, $like, $like);
    $types .= "sssss";
}

$whereSql = $where ? ("WHERE " . implode(" AND ", $where)) : "";

$sql = "SELECT application_id, first_name, last_name, cnic, email, phone,
               university, program, percentage, status, created_at
        FROM applications
        $whereSql
        ORDER BY created_at DESC";

$stmt = $conn->prepare($sql);
if ($types !== "") {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

echo json_encode($rows);
$stmt->close();
$conn->close();
?>
